package com.sist.dao;

import java.util.*;
import java.sql.*;

public class DataBoardDAO {
	private Connection conn;
	private PreparedStatement ps;
	private final String URL="jdbc:oracle:thin:@localhost:1521:ORCL";
	private static DataBoardDAO dao;
	
	//����̹� ���
	public DataBoardDAO() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		}catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
	}
	//�̱���
	public static DataBoardDAO newInstance() {
		if(dao==null)
			dao=new DataBoardDAO();
		return dao;
	}
	
	//����
	public void getConnection() {
		try {
			conn=DriverManager.getConnection(URL, "scott", "tiger");
		}catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
	}
	
	//����
	public void disConnection() {
		try {
			if(ps!=null)ps.close();
			if(conn!=null)conn.close();
		}catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
	}
	
	//��ü ������ �б�
		//databoardListData(int );
	
		int start=0;
		int end=9;
		
		String sql="SELECT no,subject,name,regdate,hit,num "
				+"FROM (SELECT no,subject,name,regdate,hit,rownum as num "
				+"FROM (SELECT no,subject,name,regdate,hit "
				+"FROM dataBoard ORDER BY no DESC))"
				+"WHERE num BETWEEN "+start+ " AND "+end;
	
	//��������
		//databoardTotalPage();
		sql="SELECT CEIL(COUNT(*)/10) FROM dataBoard";
	//���뺸��
		//databoardContent();
		sql="UPDATE databoard SET "+
				"hit=hit+1 "+ "WHERE no=?";
		sql="SELECT no,name,subject,content,regdate,hit,"
				+"filename,filesize "
				+"FROM databoard "
				+"WHERE no=?";
	//�۾��� (UPLOAD)
		//databoardInsert()
		sql="INSERT INTO databoard(no,name,subject,content,pwd,filname,filesize) "
			+"VALUES(seq_db_no.nextval,?,?,?,?,?,?)";
	//����
		//databoardDelete()
		sql="SELECT pwd FROM databoard "
				+"WHERE no=?";
		
		sql="DELETE FROM databoard "
				+"WHERE no=?";
				
	//��������
		
	//�����ϱ�
		//dataBoardUpdateData()
		
		//dataBoardUpdate()
		
	}
}




























