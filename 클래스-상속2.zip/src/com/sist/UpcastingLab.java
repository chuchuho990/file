package com.sist;

class Person{
	String name;
	String id;
	
	public Person(String name) {
		this.name=name;		
	}
}

class Student extends Person{
	String grade;
	String department;
	
	public Student(String name) {
		super(name);
	}
}

public class UpcastingLab {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Person p;
		Student s=new Student("�̼���");
		//p=s;
		Person p=new Student("�̼���");//��ĳ����
		System.out.println(p.name);
		
		//p.grade="A";		//�����Ͽ���
		//p.department="Com"; //�����Ͽ���
	}

}




















