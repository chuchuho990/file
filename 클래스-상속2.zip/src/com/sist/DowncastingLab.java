package com.sist;

class Person1{
	String name;
	String id;
	
	public Person1(String name) {
		this.name=name;		
	}
}

class Student1 extends Person1{
	String grade;
	String department;
	
	public Student1(String name) {
		super(name);
	}
}

public class DowncastingLab {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person1 p=new Student1("������"); //��ĳ����
		Student1 s;
		
		s=(Student1)p;	//�ٿ�ĳ����
		
		System.out.println(s.name);
		s.grade="A";
		
	}

}




















