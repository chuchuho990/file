package com.sist.data;

public class BoardVO {

}
