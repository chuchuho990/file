package com.sist.data;

public class BoardTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("******�ϹݰԽ��� ���******\n");
		BoardDAO b=new BoardDAO();
		b.insert();
		b.update();
		b.list();
		b.delete();
		b.find();
		
		System.out.println("******��۰Խ��� ���******\n");
		//ReplyBoardDAO rb=new ReplyBoardDAO();
		BoardDAO rb=new ReplyBoardDAO();
		rb.insert();
		rb.update();
		rb.delete();
		rb.list();
		rb.find();
		//rb.replyInsert();
		//rb.replyList();
		
		System.out.println("******�亯 �Խ��� ���******\n");
		ARBoardDAO arb=new ARBoardDAO();
		arb.delete();
		arb.find();
		arb.list();
		arb.insert();
		arb.update();
		
		System.out.println("******�������Խ��� ���******\n");
		GalleryBoardDAO gb=new GalleryBoardDAO();
		gb.delete();
		gb.find();
		gb.insert();
		gb.update();
		gb.upload();
	}

}




















