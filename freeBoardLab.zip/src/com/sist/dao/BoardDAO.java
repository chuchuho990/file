package com.sist.dao;
import java.util.*;
import java.sql.*;
//DAO => DBCP => ORM => JPA

public class BoardDAO {
	private Connection conn;
	private PreparedStatement ps;
	private final String URL="jdbc:oracle:thin:@localhost:1521:ORCL";
	private final String USERNAME="scott";
	private final String PWD="tiger";
	private static BoardDAO dao;
	
	public BoardDAO() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		}catch(Exception ex) {
			System.out.println();
		}
	}
	//��Ŭ�� ����
	public static BoardDAO newInstance() {
		if(dao==null)
		dao=new BoardDAO();
	return dao;		
	}
	
	public void getConnection() {
		try {
			conn=DriverManager.
					getConnection(URL, USERNAME, PWD);
		}catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
	}
	
	public void disConnection() {
		try {
			if(ps!=null)ps.close();
			if(conn!=null) conn.close();
		}catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
	}
	
	public List<BoardVO> boardAllData(int page){
		List<BoardVO> list=new ArrayList<>();
		
		try {
			getConnection();
			String sql="SELECT no,subject,name,regdate,hit "
					+"FROM freeBoard "
					+"ORDER BY no DESC";
			ps=conn.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			int i=0;	//10���� �����ִ� ����
			int j=0;	//while�� ���ư��� Ƚ�� 
			//0~9, 10~19, 20~29
			int pagecnt=(page*10)-10;
			while(rs.next()) {
				if(i<10 && j>=pagecnt) {
					BoardVO vo=new BoardVO();
					vo.setNo(rs.getInt(1));
					vo.setSubject(rs.getString(2));
					vo.setName(rs.getString(3));
					vo.setRegdate(rs.getDate(4));
					vo.setHit(rs.getInt(5));
					list.add(vo);
					i++;	
				}
				j++;
			}
				
		}catch(Exception ex) {
			System.out.println(ex.getMessage());
		}finally {
			disConnection();
		}
		
		return list;
	}
	
	//�������� ���ϱ�  CEIL()
	public int boardTotalPage() {
		int total=0;
		
		try {
			getConnection();
			String sql=
				"SELECT CEIL(count(*)/10) FROM freeBoard";
			
			ps=conn.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			rs.next();
			total=rs.getInt(1);
			rs.close();
			
			
		}catch(Exception ex) {
			System.out.println(ex.getMessage());
		}finally {
			disConnection();
		}
		
		
		return total;
	}
	
}


























