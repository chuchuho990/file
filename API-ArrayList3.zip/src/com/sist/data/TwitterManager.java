package com.sist.data;

import twitter4j.FilterQuery;
import twitter4j.TwitterStream;
import twitter4j.TwitterStreamFactory;

public class TwitterManager {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			TwitterStream ts=
				new TwitterStreamFactory().getInstance();
			TwitterListener list=new TwitterListener();
			ts.addListener(list);
			
			String[] data= {"������","Ʈ����","������","�ƺ�","������",
					"Ǫƾ","�����콺"};
			FilterQuery fq=new FilterQuery();
			fq.track(data);
			ts.filter(fq);
		}catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
	}

}

















