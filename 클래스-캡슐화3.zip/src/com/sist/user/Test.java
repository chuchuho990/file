package com.sist.user;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="12.3|45.6|78.9";
		String[] arr=str.split("\\|");
		for(int i=0;i<arr.length;i++) {
			System.out.println(arr[i]);
		}
	}

}








