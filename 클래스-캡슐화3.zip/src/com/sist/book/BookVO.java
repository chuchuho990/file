package com.sist.book;
//����(scope)
/*
 *  1.��������,�Ű����� �켱����
 *  2.�������(��������)
 */
public class BookVO {
	private String title;
	private String author;
	private String pulisher;
	private String regdate;
	private int price;
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String t) {
		this.title=t;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String a) {
		this.author=a;
	}
	public String getPulisher() {
		return pulisher;
	}
	public void setPulisher(String p) {
		this.pulisher=p;
	}
	public String getRegdate() {
		return regdate;
	}
	public void setRegdate(String r) {
		this.regdate=r;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int p) {
		this.price=p;
	}
}










