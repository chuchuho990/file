package com.sist.book;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class BookManager {
	private static final int COUNT=20;
	private static BookVO[] bookList=
			new BookVO[COUNT];
	
	public BookManager() {
		bookDataLoading();
	}
	/*
	<dl class="prod_info">
		<dt>
			<a href="/front/product/detailProduct.do?prodId=3983105" onfocus="this.blur();">
				  ����� �µ�
			</a> 												
			<span class="tag_area">
				<span class="tag_best"><span>����Ʈ</span></span>
				<span class="tag_recom"><span>�ݵ���õ</span></span>
				
				<span class="tag_free"><span>������</span></span>
			</span>
		</dt>
		<dd class="txt_block">
			<span>�̱���</span> <span class="gap">|</span> <span>������</span>
			<span class="txt_date"><span class="gap">|</span> <span>2016.08.19</span></span>
		</dd>
		<dd class="mt5"><p><span class="txt_reprice">13,800��</span> <span class="txt_arrow">��</span> 
							<span class="txt_price"><strong><em>12,420</em>��</strong>
							 (10%��+5%P)</span></p></dd>	 * 
	 */
	//20���� å���
	public void bookDataLoading() {
		try {
			Document doc=
			Jsoup.connect("http://www.bandinlunis.com/front/display/listBest.do").get();
			
			Elements title=doc.select("dl.prod_info dt a");
			Elements info=doc.select("dd.txt_block");
			Elements price=doc.select("dd.mt5 span.txt_reprice");
			
			for(int i=0;i<COUNT;i++) {
				Element t=title.get(i);
				Element in=info.get(i);
				Element p=price.get(i);
				
				System.out.println(t.text()+" "
						+in.text()+" "
						+p.text());
				
				BookVO vo=new BookVO();
				vo.setTitle(t.text());	
				
				String[] data=in.text().split("\\|");
				vo.setAuthor(data[0]);
				vo.setPulisher(data[1]);
				vo.setRegdate(data[2]);
				
				String pp=p.text().substring(
						0, p.text().lastIndexOf("��"));
				pp=pp.replace(",", "");
				vo.setPrice(Integer.parseInt(pp));
				bookList[i]=vo;
			}			
			
		}catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
	}
	
	//5���� ���
	public BookVO[] bookAllData(int page) {
		BookVO[] data=new BookVO[5];
		int rowSize=5;
		int j=0;
		int pagecnt=(page*rowSize)-rowSize;	//1 =>0~4
											//2 =>5~9
											//3 =>10~14
											//4 =>15~19
		for(int i=0;i<COUNT;i++) {
			if(j<5 && i>=pagecnt) {
				data[j]=bookList[i];
				j++;
			}
			
		}
		return data;
	}
	
	public int bookTotal() {
		return (int)(Math.ceil(COUNT/5.0));
	}
}























