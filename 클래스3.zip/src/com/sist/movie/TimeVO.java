package com.sist.movie;

public class TimeVO {
	int tno;
	String time;
}
