package com.sist.movie;

public class MovieVO {
	int mno;
	String title;
	String grade;
	String theater;
	
}
