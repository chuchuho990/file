package com.sist.movie;

public class ThreaterVO {
	int tno;
	String name;
	String loc;
	String time;
}
