package com.sist.dao;
/*
MNO           NOT NULL NUMBER
TITLE         NOT NULL VARCHAR2(100)
POSTER        NOT NULL VARCHAR2(260)
GENRE              VARCHAR2(50)
REGDATE       NOT NULL VARCHAR2(20)
DIRECTOR      NOT NULL VARCHAR2(100)
ACTOR         NOT NULL VARCHAR2(500)
GRADE         NOT NULL VARCHAR2(30)
STORY         NOT NULL CLOB * 
 */
public class MovieVO {
	private int mno;
	private String title;
	private String poster;
	private String genre;
	private String regdate;
	private String director;
	private String actor;
	private String grade;
	private String story;
	public int getMno() {
		return mno;
	}
	public void setMno(int mno) {
		this.mno = mno;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getPoster() {
		return poster;
	}
	public void setPoster(String poster) {
		this.poster = poster;
	}
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	public String getRegdate() {
		return regdate;
	}
	public void setRegdate(String regdate) {
		this.regdate = regdate;
	}
	public String getDirector() {
		return director;
	}
	public void setDirector(String director) {
		this.director = director;
	}
	public String getActor() {
		return actor;
	}
	public void setActor(String actor) {
		this.actor = actor;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public String getStory() {
		return story;
	}
	public void setStory(String story) {
		this.story = story;
	}
	
}


















