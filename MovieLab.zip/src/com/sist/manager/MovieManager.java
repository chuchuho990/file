package com.sist.manager;

import java.util.ArrayList;
import java.util.List;

import com.sist.dao.MovieDAO;
import com.sist.dao.MovieVO;

import org.jsoup.*;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class MovieManager {
	private MovieDAO dao=new MovieDAO();
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MovieManager mm=new MovieManager();
		mm.movieAllData();
	}
	
	public List<String> movieGetCodeData(){
		List<String> list=new ArrayList<>();
		int k=1;
		
		try {
			//http://movie.naver.com/movie/sdb/rank/rmovie.nhn?sel=pnt&date=20171009&page=1
			for(int i=1;i<=20;i++) {
				Document doc=Jsoup.connect("http://movie.naver.com/movie/sdb/rank/rmovie.nhn?sel=pnt&date=20171009&page="+i).get();
				Elements atag=doc.select("td.title div.tit5 a");
				
				for(int j=0;j<atag.size();j++) {
					Element a=atag.get(j);
					String link=a.attr("href");
					String title=a.text();
					System.out.println(k+":"+link+"=>"+title);
					list.add("http://movie.naver.com"+link);
					k++;
				}
			}
		}catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
		
		return list;
	}
	
	public void movieAllData() {
		try {
			List<String> codeList=movieGetCodeData();
			int i=1;
			
			for(int k=0;k<codeList.size();k++) {
				try {
					String url=codeList.get(k);
					
					Document doc=Jsoup.connect(url).get();
					
					Element poster=doc.select("div.poster a img").first();
					Element title=doc.select("div.mv_info h3.h_movie a").first();
					Element genre=doc.select("dl.info_spec span a").first();
					Element director=doc.select("div.info_spec2 dl.step1 dd a").first();
					Elements actors=doc.select("div.info_spec2 dl.step2 dd a");
					Elements grades=doc.select("dl.info_spec dd p a");			
					Element story=doc.select("div.story_area p.con_tx").first();
					String actor="";
					for(int n=0;n<actors.size();n++) {
						actor+=actors.get(n).text()+",";
					}
					actor=actor.substring(0, actor.lastIndexOf(","));
					
					String gg="";
					String day="";
					for(int n=0;n<grades.size();n++) {
						Element grade=grades.get(n);
						String str=grade.attr("href")
							.substring(grade.attr("href").indexOf("?")+1, 
									grade.attr("href").lastIndexOf("="));
						
						if(str.equals("grade")) {
							gg=grade.text();
							break;
						}
						if(str.equals("open")) {
							day+=grade.text();
						}
						
					}
					day=day.substring(0, 10);
					
					String s=story.text().replaceAll("[^��-�R]", "");
					
					MovieVO vo=new MovieVO();
					vo.setMno(i);
					vo.setTitle(title.text());
					vo.setDirector(director.text());
					vo.setActor(actor);
					vo.setPoster(poster.attr("src"));
					vo.setGenre(genre.text());
					vo.setRegdate(day);
					vo.setStory(s);
					vo.setGrade(gg);
					//����Ŭ ����
					dao.movieInsert(vo);
					System.out.println(i+"�߰�");
					
				}catch(Exception ex) {
					System.out.println(ex.getMessage());
				}
				i++;
			}
			
		}catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
	}

}









