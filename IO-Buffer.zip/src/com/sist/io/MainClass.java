package com.sist.io;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/*
 * 	=FileInputStream,FileOutputStream
 *   FileReader,FileWriter
 *  =BufferedReader,BufferedWriter
 *  
 *  =ObjectInputSteam,ObjectOutputStream
 *   
 *  =InputSteamReader
 *   =================web : Request,Response 
 */
public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			//��Ʈ��ũ,����
			BufferedReader in=
					new BufferedReader(
							new InputStreamReader(System.in));
			//InputStream Reader
			//Buffer => ����� �Է°� �ӵ��� ���߱� ���� ���
			System.out.print("���ڿ��� �Է��Ͻÿ�: ");
			String data=in.readLine();
			System.out.println(data);
		}catch(Exception ex) {
			System.out.println();
		}
	}

}


















