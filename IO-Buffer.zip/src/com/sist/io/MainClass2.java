package com.sist.io;

import java.io.*;
import java.net.*;
public class MainClass2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			URL url=new URL("https://github.com/");
			HttpURLConnection conn=
				(HttpURLConnection) url.openConnection();
			
			if(conn!=null) {
				BufferedReader in=
					new BufferedReader(
						new InputStreamReader(
							conn.getInputStream(), "UTF-8"));
				while(true) {
					String data=in.readLine();
					if(data==null)
						break;
					System.out.println(data);
				}
			}
			
			
		}catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
	}

}























