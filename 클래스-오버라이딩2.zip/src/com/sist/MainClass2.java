package com.sist;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.*;

public class MainClass2 extends JFrame
						implements KeyListener{
	ImageView iv=new ImageView();
	
	public MainClass2() {
		add("Center", iv);
		
		setSize(800, 600);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		addKeyListener(this);
	}
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new MainClass2();
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		switch(e.getKeyCode()) {
		case KeyEvent.VK_RIGHT:
			iv.setImage(0);
			iv.x+=5;
			if(iv.x>800)
				iv.x=0;
			break;
		case KeyEvent.VK_LEFT:
			iv.setImage(0);
			iv.x-=5;
			if(iv.x<0)
				iv.x=800;
			break;
		case KeyEvent.VK_UP:
			iv.setImage(0);
			iv.y-=5;
			if(iv.y<0)
				iv.y=600;
			break;
		case KeyEvent.VK_DOWN:
			iv.setImage(0);
			iv.y+=5;
			if(iv.y>600)
				iv.y=0;
			break;
		case KeyEvent.VK_ENTER:
			iv.setImage(1);
			break;
			
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

}
