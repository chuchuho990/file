
class Sort{
	public void selectSort(int[] a) {
		int i,j,min;
		for(i=0;i<a.length-1;i++) {
			min=i;
			for(j=i+1;j<a.length;j++) {
				if(a[j]<a[min]) {
					min=j;
				}
			} //
				swap(a,min,i);
				System.out.printf("\n���� ���� %d �ܰ� : ",i+1);
				for(j=0;j<a.length;j++) {
					System.out.printf("%3d",a[j]);
				}
		}
	}//end of selectSort()
	
	public void swap(int[] a,int i,int j) {
		int temp=a[i];
		a[i]=a[j];
		a[j]=temp;
	}
	
}

public class �迭6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] a= {69,10,30,2,16,8,31,22};
		Sort s=new Sort();
		System.out.printf("\n������ ����: " );
		for(int i=0;i<a.length;i++) {
			System.out.printf(" %d",a[i]);
		}
		System.out.println();
		s.selectSort(a);
	}

}













