
public class �迭5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr=new int[5];
		int[] rank=new int[5];
		
		//�迭�ʱ�ȭ
		for(int i=0;i<5;i++) {	// �迭�ʱ�ȭ [45,46,47,92,61,21]]
			arr[i]=(int)(Math.random()*100)+1;
		}
		
		for(int i=0;i<5;i++) {
			rank[i]=1;
			for(int j=0;j<5;j++) {
				if(arr[i]<arr[j]) {
					rank[i]++;		//�� �������� ��
				}
			}
		}
		
		for(int i=0;i<5;i++) {
			System.out.println(arr[i]+" "
					+rank[i]);
		}
		
		for(int i=0;i<5;i++) {
			System.out.print(arr[i]+" ");
		}
		
		for(int i=0;i<5;i++) {
			for(int j=i+1;j<arr.length;j++) {
				if(arr[i]<arr[j]) {  //������<ū��
					int temp=arr[i];	//������
					arr[i]=arr[j];		//ū��
					arr[j]=temp;		//������
					
				}
			}
		}
		System.out.println();
		for(int i=0;i<5;i++) {
			System.out.print(arr[i]+" ");
		}
		
		System.out.println();
		for(int i=0;i<5;i++) {
			for(int j=i+1;j<arr.length;j++) {
				if(arr[i]>arr[j]) {  //ū��>������
					int temp=arr[i];	//ū��
					arr[i]=arr[j];		//������
					arr[j]=temp;		//ū��
					
				}
			}
		}
		System.out.println();
		for(int i=0;i<5;i++) {
			System.out.print(arr[i]+" ");
		}		
	}

}














