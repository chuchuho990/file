//5���� �����߻� ==> �ִ밪,�ּҰ�
public class �迭3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a,b,c,d,e;
		int max,min;
		a=(int)(Math.random()*100)+1;
		b=(int)(Math.random()*100)+1;
		c=(int)(Math.random()*100)+1;
		d=(int)(Math.random()*100)+1;
		e=(int)(Math.random()*100)+1;
		
		max=a;
		if(max<b)
			max=b;
		if(max<c)
			max=c;
		if(max<d)
			max=d;
		if(max<e)
			max=e;
		
		min=a;
		if(min>b)
			min=b;
		if(min>c)
			min=c;
		if(min>d)
			min=d;
		if(min>e)
			min=e;
		System.out.println("������:" +a+","
			+b+","+c+","+d+","+e);
		System.out.println("�ִ밪:"+max);
		System.out.println("�ּҰ�:"+min);
		
		System.out.println();
		
		int[] data=new int[10];
		int max1,min1;
		for(int i=0;i<data.length;i++) {
			data[i]=(int)(Math.random()*100)+1;
			System.out.printf("%d ",data[i]);
		}
		max1=data[0];
		min1=data[0];
		for(int i=0;i<data.length;i++) {
			if(max1<data[i])
				max1=data[i];
			if(min1>data[i])
				min1=data[i];
		}
		System.out.println();
		System.out.println("�ִ밪: "+max1);
		System.out.println("�ּҰ�: "+min1);
	}

}




















