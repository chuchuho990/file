package com.sist.movie;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

/*
    <div class="box-image" >
        <strong class="rank">No.1</strong>	
        <a href="/movies/detail-view/?midx=79846">
            <span class="thumb-image">
                <img src="http://img.cgv.co.kr/Movie/Thumbnail/Poster/000079/79846/79846_185.jpg" alt="���̾����� ������" onerror="errorImage(this)"/>
                <span class="ico-grade grade-19">û�ҳ� �����Ұ�</span>
            </span>
            <strong class="no1">1��</strong>
        </a>
        <span class="screentype">
            
        </span>
    </div>
    
    <div class="box-contents">
        <a href="/movies/detail-view/?midx=79846">
            <strong class="title">���̾�����</strong>
        </a>

 * 
 */
public class MovieCGVManager {
	
	public MovieVO[] getMovieData() {
		MovieVO[] mv=new MovieVO[7];
		try {
			Document doc=Jsoup.connect("http://www.cgv.co.kr/movies/?ft=0").get();
			Elements pelem=doc.select("div.box-image span.thumb-image img");
			Elements telem=doc.select("div.box-contents strong.title");
			
			for(int i=0;i<mv.length;i++) {
				Element poster=pelem.get(i);
				String pos=poster.attr("src");
				Element title=telem.get(i);
				
				MovieVO vo=new MovieVO();
				vo.setTitle(title.text());
				vo.setPoster(pos);
				mv[i]=vo;
				
			}
			
		}catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
			
		
		return mv;
	}
}


















