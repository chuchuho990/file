package com.sist.movie;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class MovieMain extends JFrame
					implements MouseListener{
	JLabel la1,la2,la3;
	JTable table1,table2,table3;
	DefaultTableModel model1,model2,model3;
	JLabel[] poster=new JLabel[7];
	
	MovieCGVManager mgr=new MovieCGVManager();
	
	public Image getImageChange(ImageIcon img,int width,int height) {
		Image i=img.getImage();
		Image c=i.getScaledInstance(width, height, Image.SCALE_SMOOTH);
		return c;
	}
	
	public MovieMain() {
		JMenuBar bar=new JMenuBar();
		
		JMenu menu1=new JMenu("Ȩ");
		JMenuItem item1=new JMenuItem("Ȩ");
		JMenuItem item2=new JMenuItem("��ȭ���");
		JMenuItem item3=new JMenuItem("����");
		menu1.add(item1);
		menu1.add(item2);
		menu1.add(item3);
		bar.add(menu1);
		
		JMenu menu2=new JMenu("��ȭ����");
		JMenuItem item4=new JMenuItem("���� ����");
		JMenuItem item5=new JMenuItem("��ȭ ����");
		menu2.add(item4);
		menu2.add(item5);
		bar.add(menu2);
		
		JMenu menu3=new JMenu("��������");
		JMenuItem item6=new JMenuItem("����");
		JMenuItem item7=new JMenuItem("����������");		menu2.add(item4);
		menu3.add(item6);
		menu3.add(item7);
		bar.add(menu3);	
		setJMenuBar(bar);
		
		setLayout(null);
		
		setSize(900,700);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
	}
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new MovieMain();
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

}

























