package �޼ҵ�2;

import java.util.Scanner;

public class �޼ҵ�2 {
	
	static int[] inputNumber(String title) {
		Scanner scan=new Scanner(System.in);
		int[] temp=new int[3];
		
		for(int i=0;i<3;i++) {
			System.out.printf("%d��° %s���� �Է�:",(i+1),title);
			temp[i]=scan.nextInt();
		}
		
		return temp;
	}
	
	static int[] getTotal(int[] k,int[] e,int[] m) {
		int[] total=new int[3];
		
		for(int i=0;i<3;i++) {
			total[i]=k[i]+e[i]+m[i];
		}
		
		return total;
	}
	
	static int[] getAvg(int[] total) {
		int[] avg=new int[3];
		
		for(int i=0;i<3;i++) {
			avg[i]=total[i]/3;
		}
		
		return avg;
	}
	
	static char[] getHakjum(int[] avg) {
		char[] hak=new char[3];
		
		for(int i=0;i<3;i++) {
			switch(avg[i]/10) {
			case 10:
			case 9:
				hak[i]='A';
				break;
			case 8:
				hak[i]='B';
				break;
			case 7:
				hak[i]='C';
				break;
			case 6:
				hak[i]='D';
				break;
			default:
				hak[i]='F';
				break;
			}
		}
		return hak;
	}
	
	static int[] getRank(int[] total) {
		int[] rank=new int[3];
		
		for(int i=0;i<3;i++) {
			rank[i]=1;
			for(int j=0;j<3;j++) {
				if(total[i]<total[j]) {
					rank[i]++;
				}
			}
		}
		
		return rank;
	}
	
	public static void main(String[] args) {
		int[] kor=inputNumber("����");
		int[] eng=inputNumber("����");
		int[] math=inputNumber("����");
		
		int[] total=getTotal(kor, eng, math);
		int[] avg=getAvg(total);
		char[] hak=getHakjum(avg);
		int[] rank=getRank(total);
		
		System.out.printf("%6s%9s%9s%9s%9s%6s%6s\n",
						"����","����","����","����","���","����","���");
		for(int i=0;i<3;i++) {
			System.out.printf("%5d%5d%5d%7d%5d%3s%5d\n",
						kor[i],eng[i],math[i],total[i],
						avg[i],hak[i],rank[i]);
		}
	}

}





















