package com.sist.xml;
//DOM

import java.util.*;
import javax.xml.parsers.*;
import java.io.*;
import org.w3c.dom.*;

public class SawonXML {
	//������ġ(�޸�) Document (Database) => ORCL
	private Document doc; 	//xml ������ �ش�. XML �������� ��� Ž��,���� ��� ����
	private static SawonXML xml;  //table�� �ش�.
	private Element root;	//xml �������� ��ҿ� �ش��ϴ� ��ü�� �ٷ�.
	private String path="C:\\WebProjects\\webLab2\\XMLLab2\\WebContent\\WEB-INF\\sawon.xml";
	
	public SawonXML() {
		try {
			//�ļ��� ���
			DocumentBuilderFactory dbf=
					DocumentBuilderFactory.newInstance();
			DocumentBuilder db=dbf.newDocumentBuilder();
			doc=db.parse(new File(path));
			root=doc.getDocumentElement();	//������ �ֻ��� ��Ҹ� ��ȯ.
		}catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
	}
	
	public static SawonXML newInstance() {
		if(xml==null)
			xml=new SawonXML();
		return xml;
	}
	
	public List<SawonVO> sawonAllData(){
		List<SawonVO> list=new ArrayList<>();
		
		try {
			NodeList node=
					root.getElementsByTagName("list");
			for(int i=0;i<node.getLength();i++) {
				node=root.getElementsByTagName("sabun");
				String sabun=node.item(i).getFirstChild().getNodeValue();
				
				node=root.getElementsByTagName("name");
				String name=node.item(i).getFirstChild().getNodeValue();
				
				node=root.getElementsByTagName("dept");
				String dept=node.item(i).getFirstChild().getNodeValue();
					
				node=root.getElementsByTagName("loc");
				String loc=node.item(i).getFirstChild().getNodeValue();

				node=root.getElementsByTagName("hiredate");
				String hiredate=node.item(i).getFirstChild().getNodeValue();
				
				SawonVO vo=new SawonVO();
				vo.setSabun(Integer.parseInt(sabun));
				vo.setName(name);
				vo.setDept(dept);
				vo.setLoc(loc);
				vo.setHiredate(hiredate);
				list.add(vo);
				
			}
			
		}catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
		
		
		
		return list;
	}
	
}






















