package com.sist.controller;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.*;
import java.util.*;
import com.sist.model.*;

public class DispatcherServlet extends HttpServlet{
	
	private Map clsMap=new HashMap();
	String[] strCls= {"com.sist.model.ListModel","com.sist.model.DeleteModel"};
	String[] strCmd= {"list","delete"};
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		try {
			for(int i=0;i<strCmd.length;i++) {
				Class clsName=Class.forName(strCls[i]);
				//�������
				Object obj=clsName.newInstance();
				
				clsMap.put(strCmd[i], obj);
			}
			
			
		}catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
	}
	
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			String cmd=request.getRequestURI();
			cmd=cmd.substring(
					request.getContextPath().length()+1, 
					cmd.lastIndexOf('.'));
			
			Model model=(Model) clsMap.get(cmd);
			String jsp=model.execute(request);
			String ext=jsp.substring(jsp.lastIndexOf('.')+1); //do
			if(ext.equals("do")) {
				response.sendRedirect(jsp);
			}else {
				RequestDispatcher rd
				=request.getRequestDispatcher(jsp);
				rd.forward(request, response);
			}
		
			
			
		}catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
	}
	
	
}




















