package com.sist.model;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.sist.xml.SawonVO;
import com.sist.xml.SawonXML;

public class ListModel implements Model{

	@Override
	public String execute(HttpServletRequest request) throws Exception {
		
		SawonXML xml=SawonXML.newInstance();
		List<SawonVO> list=xml.sawonAllData();
		request.setAttribute("list", list);
		
		return "sawon/list.jsp";
	}

}





