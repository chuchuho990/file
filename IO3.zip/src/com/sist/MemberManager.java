package com.sist;

import java.io.*;
import java.util.*;
public class MemberManager {
	ArrayList<MemberVO> list=
			new ArrayList<>();
	
	public MemberManager() {
		init();
	}
	
	public void init() {
		MemberVO vo=new MemberVO();
		vo.setId("jung");
		vo.setName("������");
		vo.setPwd("1234");
		list.add(vo);

		vo=new MemberVO();
		vo.setId("lee");
		vo.setName("�̼���");
		vo.setPwd("1234");
		list.add(vo);
		
		vo=new MemberVO();
		vo.setId("choi");
		vo.setName("�ֿ�");
		vo.setPwd("1234");
		list.add(vo);	
		
		try {
			ObjectOutputStream oos=
				new ObjectOutputStream(
					new FileOutputStream(
					"c:\\download\\member.txt"));
			oos.writeObject(list);
			oos.close();
			
			
		}catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
				
	}
	
	public ArrayList<MemberVO> memberAllData(){
		try {
			ObjectInputStream ois=
				new ObjectInputStream(
					new FileInputStream(
						"c:\\download\\member.txt"));
			list=(ArrayList<MemberVO>)ois.readObject();
		}catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
		return list;
	}
}






















