package com.sist;

import java.util.ArrayList;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MemberManager m=new MemberManager();
		ArrayList<MemberVO> list=m.memberAllData();
		for(MemberVO vo:list) {
			System.out.println(vo.getId()+" "
					+vo.getPwd()+" "
					+vo.getName());
		}
	}

}



