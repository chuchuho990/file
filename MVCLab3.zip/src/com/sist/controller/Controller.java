package com.sist.controller;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sist.model.DeleteModel;
import com.sist.model.InsertModel;
import com.sist.model.ListModel;
import com.sist.model.UpdateModel;

import java.util.*;
import java.io.*;

public class Controller  extends HttpServlet{
	private Map clsMap=new HashMap();
	//*.do ===>Controller
	// http://localhost:8080/MVCLab3/list.do ==> ListModel => list.jsp
	// http://localhost:8080/MVCLab3/delete.do
	// http://localhost:8080/MVCLab3/insert.do
	// http://localhost:8080/MVCLab3/update.do
	// /Controller?menu=list
	
/*	private String[] strCmd= {
			"list","delete","insert","update"
	};*/
	
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			String menu=request.getParameter("menu");
			String jsp="";
			
			if(menu.equals("list")) {
				ListModel model=new ListModel();
				model.execute(request);
				
			}else if(menu.equals("delete")) {
				DeleteModel model=new DeleteModel();
				model.execute(request);				
			}else if(menu.equals("update")) {
				UpdateModel model=new UpdateModel();
				model.execute(request);					
			}else if(menu.equals("insert")) {
				InsertModel model=new InsertModel();
				model.execute(request);					
			}
			
			RequestDispatcher rd=
					request.getRequestDispatcher("view/"
					+menu+".jsp");
			
			rd.forward(request, response);
			
			
			
			
		}catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
	}
}

















