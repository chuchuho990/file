package com.sist;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class MainClass2 extends JFrame 
				implements ActionListener {
	JTextField tf;
	JPasswordField pf;
	JButton b1,b2;
	JLabel la1,la2;
	
	public MainClass2() {
		tf=new JTextField();
		pf=new JPasswordField();
		b1=new JButton("�α���");
		b2=new JButton("���");
		la1=new JLabel("ID");
		la2=new JLabel("PW");
		
		//��ġ
		setLayout(null);
		la1.setBounds(10, 15, 30, 20);
		tf.setBounds(45, 15, 125, 20);
		la2.setBounds(10, 40, 30, 20);
		pf.setBounds(45, 40, 125, 20);
		
		JPanel p=new JPanel();
		p.add(b1);
		p.add(b2);
		p.setBounds(10, 65, 180, 35);
		
		add(la1);add(tf);
		add(la2);add(pf);
		add(p);
		//
		setSize(220, 150);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		b1.addActionListener(this);
		b2.addActionListener(this);
		
	}
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MainClass2 m=new MainClass2();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==b1) {
			JOptionPane.showMessageDialog(this, "�α��� �Ǿ����ϴ�.");
		}
		if(e.getSource()==b2) {
			System.exit(0);
		}
	}

}
















