package com.sist.mgr;
import java.lang.annotation.ElementType;
import java.util.*;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class MovieManager {
	
	public List<MovieVO> getMovieData(){
		List<MovieVO> mv=new ArrayList<>();
		
		try {
			Document doc=
					Jsoup.connect("http://www.cgv.co.kr/movies/?ft=0").get();
			Elements titleElem=doc.select("div.box-contents strong.title");
			//
			
			
			
			for(int i=0;i<7;i++) {
				Element telem=titleElem.get(i);
				//
				
				MovieVO d=new MovieVO();
				d.setTitle(telem.text());
				//
				
				mv.add(d);
			}
			
			
		}catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
		
		return mv;
	}
}





















