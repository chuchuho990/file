package com.sist.controller;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
import java.util.*;

/*
 * 		<?xml version="1.0" encoding="UTF-8"?>	  startDocument() : ������ ����
 * 		<beans>									  startElement()
 * 			<context:component-scan />			  startElement()	�Ӽ��б�   endElement()
 * 			<context:component-scan />			  startElement()	�Ӽ��б�   endElement()
 * 			<context:component-scan />			  startElement()	�Ӽ��б�   endElement()
 * 		</beans>								  endElement()	
 * 												   endDocument()
 */

public class HandlerMapping extends DefaultHandler{
	List<String> list=new ArrayList<>();
	
	
	@Override
	public void startElement(String uri, String localName, String qName, Attributes attr) throws SAXException {
		try {
			if(qName.equals("context:component-scan")) {
				String pack=attr.getValue("base-package");
				list.add(pack);
			}
		}catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
	}
}















