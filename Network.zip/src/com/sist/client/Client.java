package com.sist.client;

import java.net.*;
import java.io.*;
public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			Socket s=
				new Socket("localhost", 3535);	
			
			BufferedReader in=
				new BufferedReader(
					new InputStreamReader(
						s.getInputStream()));
			System.out.println(in.readLine());
			
		}catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
	}

}













